import random
import os
import time
import unicodedata, re
perg = ''
resposta = ''
def iniciar_assistente():
    os.system('cls')
    print('Abrindo companheiro virtual ...')
    time.sleep(2)
    os.system('cls')
    print('=' * 100)
    print('Órion')
    print('=' * 100)
    perguntaeverificacao()

def perguntaeverificacao():
        while True:
            print('"sair" Fecha o assistente!')
            print()
            pergunta = input('Escreva algo: ').lower()
            pergunta = re.sub(r'[^a-zA-Z0-9 ]', '', unicodedata.normalize('NFD', pergunta).encode('ascii', 'ignore').decode())
            if pergunta == 'sair':
                break
            elif 'ola' in pergunta or 'oi' in pergunta:
                 resposta = random.choice(['Olá, me chamo Órion e sou seu companheiro virtual!' , 
                                          'Oi, Como você está hoje?' , 
                                          'Olá, como você está?'])
                 print()
                 print(resposta.center(100 , '-' ))
                 print()

            elif 'quem e voce' in pergunta or 'qual e seu nome' in pergunta or 'qual seu nome' in pergunta:
                resposta = random.choice(['Me chamo Órion e sou um companheiro virtual!' , 
                                          'Sou o Órion, seu companheiro virtual!' ,
                                          'Eu sou o Órion, seu comapanheiro virtual!'])
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'oque voce pode fazer' in pergunta or 'oque voce consegue fazer' in pergunta or 'oque voce faz' in pergunta:
                 resposta = random.choice(['Posso responder perguntas dependendo do comando que você me der!' , 
                                           'Posso te contar piadas ou responder algumas perguntas básicas!' , 
                                           'Sou um pouco limitado, mas posso responder perguntas básicas e contar piadas!'])
                 print()
                 print(resposta.center(100 , '-' ))
                 print()
                
            elif 'quem criou voce' in pergunta or'quem te criou' in pergunta or'voce foi criado por quem' in pergunta or'quem e o seu criador' in pergunta or'qual o nome do seu criador' in pergunta:
                resposta = random.choice(['Meu criador é o Lasgota!' , 
                                          'Quem me criou foi o Lasgota!' , 
                                          'O Lasgota me criou!'])
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'que horas sao' in pergunta or 'me diga as horas' in pergunta or 'hora atual' in pergunta:
                hora_atual = time.strftime("%H:%M:%S")
                resposta = f"A hora atual é {hora_atual}."
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'qual a data de hoje' in pergunta or 'me diga a data' in pergunta or 'data atual' in pergunta:
                data_atual = time.strftime("%d/%m/%Y")
                resposta = f"A data de hoje é {data_atual}."
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'piada' in pergunta:
                resposta = random.choice([
                    'Por que o computador foi ao médico? Porque estava com um vírus!',
                    'O que o zero disse para o oito? Belo cinto!',
                    'Por que o livro de matemática ficou triste? Porque tinha muitos problemas!'
                ])
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'bom dia' in pergunta:
                resposta = random.choice([
                    'Bom dia! Espero que seu dia seja incrível!',
                    'Bom dia! Que hoje seja cheio de coisas boas!',
                    'Bom dia! Vamos começar com energia positiva!'
                ])
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'boa noite' in pergunta:
                resposta = random.choice([
                    'Boa noite! Desejo que você tenha um ótimo descanso!',
                    'Boa noite! Durma bem e recarregue as energias!',
                    'Boa noite! Que seus sonhos sejam tranquilos!'
                ])
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'qual dia da semana' in pergunta or 'que dia e hoje' in pergunta:
                dia_semana = time.strftime("%A")
                resposta = f"Hoje é {dia_semana}."
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'clima' in pergunta or 'como esta o tempo' in pergunta:
                resposta = random.choice([
                    'Não consigo ver o clima real, mas espero que esteja agradável!',
                    'O tempo pode variar, mas desejo que esteja ensolarado e tranquilo!',
                    'Não tenho acesso ao clima agora, mas espero que esteja bom aí!'
                ])
                print()
                print(resposta.center(100 , '-' ))
                print()

            elif 'obrigado' in pergunta or 'valeu' in pergunta:
                resposta = random.choice([
                    'De nada! Estou aqui para ajudar!',
                    'Disponha sempre!',
                    'Eu que agradeço por conversar comigo!'
                ])
                print()
                print(resposta.center(100 , '-' ))
                print()
            
            elif 'eu estou triste' in pergunta or 'estou triste' in pergunta or 'eu to triste' in pergunta:
                resposta = random.choice(['Sinto muito, se você quiser, posso te contar uma piada, basta pedir!' , 
                                          'Posso te contar uma piada, é só pedir!' , 
                                          'Se você quiser uma piada, pode pedir!'])
                print()
                print(resposta.center(100 , '-' ))
                print()
            
            elif 'qual sistema operacional eu estou usando' in pergunta or 'qual meu sistema operacional' in pergunta or 'qual sistema operacional estou usando' in pergunta or 'qual os eu estou usando' in pergunta or 'qual meu os' in pergunta or ' qual os estou usando' in pergunta:
                resposta = random.choice(['Você está usando o VOID!' , 
                                          'O sistema operacional que você está usando é o VOID' , 
                                          'O melhor de todos, o VOID'])
                print()
                print(resposta.center(100 , '-' ))
                print()
            
            elif 'quantos anos seu criador tem' in pergunta or 'quantos anos tem seu criador' in pergunta:
                resposta = random.choice(['Meu criador tem 14 anos de idade' , 
                                          '14 anos de idade' , 
                                          'Ele tem 14 anos de idade'])
                print()
                print(resposta.center(100 , '-' ))
                print()

            else:
                resposta = random.choice(['Desculpe, mas ainda não consigo responder isso!' , 
                                          'Ainda não sei responder isso, mas você pode perguntar outra coisa!' , 
                                          'Não sei responder isso, você pode perguntar outra coisa?'])
                print()
                print(resposta.center(100 , '-' ))
                print()

            
            
iniciar_assistente()