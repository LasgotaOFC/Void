def iniciar_geradordesenhas():
    import secrets
    import string
    import os
    os.system('cls')
    vault = {}  # tudo fica aqui enquanto o programa roda

    def gerar_senha():
        print("\n=== Gerador de Senhas ===")
        try:
            tamanho = int(input("Tamanho da senha (ex: 12): ") or 12)
        except:
            tamanho = 12

        usar_maius = input("Incluir MAIÚSCULAS? (S/n): ").lower().strip() != "n"
        usar_minus = input("Incluir minúsculas? (S/n): ").lower().strip() != "n"
        usar_num = input("Incluir números? (S/n): ").lower().strip() != "n"
        usar_simbol = input("Incluir símbolos? (S/n): ").lower().strip() != "n"

        tipos = ""
        if usar_minus:
            tipos += string.ascii_lowercase
        if usar_maius:
            tipos += string.ascii_uppercase
        if usar_num:
            tipos += string.digits
        if usar_simbol:
            tipos += "!@#$%^&*()-=+[]{};:,.<>/?"

        if tipos == "":
            print("Você precisa selecionar pelo menos um tipo de caractere.")
            return ""

        senha = "".join(secrets.choice(tipos) for _ in range(tamanho))
        print("\nSenha gerada:", senha)
        return senha

    def adicionar_senha():
        print("\n=== Adicionar Senha ===")
        desc = input("Descrição (ex: email, insta): ").strip()

        escolha = input("Quer DIGITAR (d) ou GERAR (g) a senha? [g/d]: ").lower().strip() or "g"

        if escolha == "d":
            senha = input("Digite a senha: ")
        else:
            senha = gerar_senha()

        if senha:
            vault[desc] = senha
            print("Senha adicionada!\n")
        else:
            print("Senha não adicionada.\n")

    def listar_senhas():
        print("\n=== Entradas ===")
        if not vault:
            print("Nenhuma senha adicionada.")
            return

        for nome in vault:
            print("-", nome)

    def ver_senha():
        print("\n=== Ver Senha ===")
        desc = input("Descrição: ")

        if desc not in vault:
            print("Não encontrado.")
            return

        print("Senha:", vault[desc])

    def deletar_senha():
        print("\n=== Deletar Senha ===")
        desc = input("Descrição: ")

        if desc not in vault:
            print("Não encontrado.")
            return

        del vault[desc]
        print("Apagado!\n")

    def menu():
        while True:
            print("\n===== MENU =====")
            print("1 - Adicionar senha")
            print("2 - Gerar senha e salvar")
            print("3 - Listar entradas")
            print("4 - Ver senha")
            print("5 - Apagar senha")
            print("6 - Sair")

            op = input("Escolha: ").strip()

            if op == "1":
                adicionar_senha()
            elif op == "2":
                desc = input("Descrição da senha: ").strip()
                senha = gerar_senha()
                if senha:
                    vault[desc] = senha
                    print("Senha adicionada ao vault!\n")
            elif op == "3":
                listar_senhas()
            elif op == "4":
                ver_senha()
            elif op == "5":
                deletar_senha()
            elif op == "6":
                print("Saindo...")
                break
            else:
                print("Opção inválida!")

    menu()  # chama o menu quando iniciar a função
