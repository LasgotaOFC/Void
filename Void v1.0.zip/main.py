import time
import os
# Apps
import advinhar
import banco
import blocodenotas
import cadastro
import calculadora
import cmd
import geradordesenhas
import hack
#import orion
import todolist

# Importações
logins = {'usuário': 'void', 'senha': 'void'}

logou = False
while True:
    print('=' * 100)
    print('Entrar')
    print('=' * 100)
    print()
    usuario = input('Usuário: ')
    senha = input('Senha: ')
    
    if usuario == logins['usuário'] and senha == logins['senha']:
        print()
        print('Verificando...')
        time.sleep(2)
        os.system('cls')
        print('Iniciando sistema!')
        print()
        time.sleep(2)
        print('sistema iniciado com sucesso!')
        print('Seja bem vindo!')
        print()
        time.sleep(2)
        logou = True
        break
    else:
        print()
        print('Verificando...')
        time.sleep(2)
        os.system('cls')
        print('')
        print('Usuário ou senha incorretos. Tente novamente.')

if logou:
    while True:
        os.system('cls')
        print('=' * 100)
        print('VOID')
        print('=' * 100)
        print()
        print('Aplicativos')
        print('[1] - Calculadora')
        print('[2] - Órion')
        print('[3] - Bloco de Notas')
        print('[4] - Lista de Tarefas')
        print('[5] - Gerador de Senhas')
        print('[6] - App de Cadastros')
        print('[7] - Banco Void')
        print('[8] - Jogo de Advinhação')
        print('"/cmd" Abre o prompt de comandos')
        print('"off" Desliga o sistema')
        app = input('Opção desejada: ')
        
        #=======================================
        # DESLIGAR
        #=======================================
        if app == 'off':
            print("Sistema desligado.")
            break

        #=======================================
        # CALCULADORA
        #=======================================
        elif app == '1':
            calculadora.iniciar_calculadora()

        #=======================================
        # ÓRION
        #=======================================
        #elif app == '2':
        #    orion.iniciar_órion()

        #=======================================
        # BLOCO DE NOTAS
        #=======================================
        elif app == '3':
            blocodenotas.iniciar_blocodenotas()

        #=======================================
        # LISTA DE TAREFAS
        #=======================================
        elif app == '4':
            todolist.iniciar_todolist()
        
        #=======================================
        # GERADOR DE SENHAS
        #=======================================
        elif app == '5':
            geradordesenhas.iniciar_geradordesenhas()

        #=======================================
        # CADASTROS
        #=======================================
        elif app == '6':
            cadastro.iniciar_cadastro()

        #=======================================
        # BANCO
        #=======================================
        elif app == '7':
            banco.iniciar_banco()

        #=======================================
        # JOGO DE ADVINHAÇÃO
        #=======================================
        elif app == '8':
            advinhar.iniciar_advinhar()

        #=======================================
        # CMD
        #=======================================
        elif app == '/cmd':
            cmd.iniciar_cmd()
            
        #=======================================
        # HACK
        #=======================================
        elif app == 'hack':
            hack.iniciar_hack()
        else:
            print("Opção inválida.")