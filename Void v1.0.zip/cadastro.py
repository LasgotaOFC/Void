def iniciar_cadastro():
    import os
# Importações Necessárias
    os.system('cls')
    pessoas = []
    dados = {}
    contagem = 0

    print('=' * 50)
    print(' Cadastro '.center(50, '-'))
    print('=' * 50)

    while True:
        dados = {
            'nome': input('Digite o nome: '),
            'idade': input('Digite a idade: '),
            'ocupação': input('Digite a ocupação: '),
            'email': input('Digite o email: '),
            'telefone': input('Digite o telefone: ')
        }

        pessoas.append(dados.copy())
        cont = input('Você quer adicionar mais uma pessoa? S/N: ')
        if cont.lower() == 'n':
            break
        elif cont.lower() == 's':
           pass

    print('-------------------- Lista de Cadastros --------------------')

    contagem = 0
    os.system('cls')
    for _ in pessoas:
        print(f"{contagem + 1} - Nome: {pessoas[contagem]['nome']} | "
              f"Idade: {pessoas[contagem]['idade']} | "
              f"Ocupação: {pessoas[contagem]['ocupação']} | "
              f"Email: {pessoas[contagem]['email']} | "
              f"Telefone: {pessoas[contagem]['telefone']}")
        contagem += 1


    # -------------- MENU DE OPÇÕES --------------
    while True:
        print()
        print('Opções:')
        print('1 - Remover pessoa')
        print('2 - Adicionar pessoa')
        print('3 - Sair')
        op = input('Qual opção você deseja: ')

        if op == '1':
            delpessoa = int(input('Digite o número da pessoa que você deseja remover: '))
            del pessoas[delpessoa - 1]
            print('Pessoa removida com sucesso')

            # LISTAR NOVAMENTE
            contagem = 0
            print()
            for _ in pessoas:
                print(f"{contagem + 1} - Nome: {pessoas[contagem]['nome']} | "
                      f"Idade: {pessoas[contagem]['idade']} | "
                      f"Ocupação: {pessoas[contagem]['ocupação']} | "
                      f"Email: {pessoas[contagem]['email']} | "
                      f"Telefone: {pessoas[contagem]['telefone']}")
                contagem += 1

        elif op == '2':
            os.system('cls')
            # ADICIONAR NOVA PESSOA
            dados = {
                'nome': input('Digite o nome: '),
                'idade': input('Digite a idade: '),
                'ocupação': input('Digite a ocupação: '),
                'email': input('Digite o email: '),
                'telefone': input('Digite o telefone: ')
            }
            pessoas.append(dados.copy())
            print('Pessoa adicionada com sucesso!')

            # LISTAR NOVAMENTE
            contagem = 0
            print()
            for _ in pessoas:
                print(f"{contagem + 1} - Nome: {pessoas[contagem]['nome']} | "
                      f"Idade: {pessoas[contagem]['idade']} | "
                      f"Ocupação: {pessoas[contagem]['ocupação']} | "
                      f"Email: {pessoas[contagem]['email']} | "
                      f"Telefone: {pessoas[contagem]['telefone']}")
                contagem += 1

        elif op == '3':
            break

        else:
            print("Opção inválida!")

    contagem = 0
