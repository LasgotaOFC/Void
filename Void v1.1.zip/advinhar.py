def iniciar_advinhar():   
    import random
    print('=' * 145)
    print(' Jogo de Advinhação '.center(145, '-'))
    print('=' * 145)

    print('Você precisa advinhar o número que estou pensando de 0 a 10')
    continuar = True

    while continuar:
        palpite = int(input('Seu palpite: '))
        num = random.randint(1, 10)
        if palpite == num:
            continuar = False
            print('Você ganhou!!!')
            input('Pressione enter pra sair: ')
        else:
            print('Errado! Tente novamente!')
            print()