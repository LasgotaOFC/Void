def iniciar_todolist():
    import os 
    os.system('cls')
    tarefas = []

    def mostrar_tarefas():
        if not tarefas:
            print("\nNenhuma tarefa ainda!")
            return
        print("\n--- Suas Tarefas ---")
        for i, t in enumerate(tarefas, start=1):
            print(f"{i}. {t}")

    def adicionar_tarefa():
        tarefa = input("Digite a nova tarefa: ")
        tarefas.append(tarefa)
        print("Tarefa adicionada!")

    def remover_tarefa():
        mostrar_tarefas()
        if tarefas:
            try:
                num = int(input("Digite o número da tarefa para remover: "))
                tarefas.pop(num - 1)
                print("Tarefa removida!")
            except:
                print("Número inválido!")

    while True:
        print()
        print('Feito Por Anonimito - Discord')
        print(' V1.0.0')
        print("--- TO-DO LIST ---")
        print("1 - Mostrar tarefas")
        print("2 - Adicionar tarefa")
        print("3 - Remover tarefa")
        print("4 - Sair")

        opc = input("Escolha: ")

        if opc == "1":
            mostrar_tarefas()
        elif opc == "2":
            adicionar_tarefa()
        elif opc == "3":
            remover_tarefa()
        elif opc == "4":
            print("Saindo...")
            break
        else:
            print("Opção inválida!")

# To com preguiça denovo!