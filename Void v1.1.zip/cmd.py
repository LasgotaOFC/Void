def iniciar_cmd():
    # |  === PROMPT DE COMANDO ===

    # | * Desenvolvido por: Lucas
    # | * Github do dev: https://github.com/lucascabral-dev
    # | * Feito para Lasgota usar em seu OS em Python.

    import os
    from time import sleep
    os.system('cls')

    print("\n[Void]. v2.0")
    print("(c) Sistema feito por Lucas para Lasgota. Todos os direitos reservados.\n")

    login_adm = False
    nome_adm = None

    lista_adms = [
        {"nome": "lasgota", "senha": "1234"},
        {"nome": "Lucas", "senha": "123"},
    ]

    # LOGIN INICIAL
    import msvcrt
    def input_senha(prompt="Senha: "):
        print(prompt, end="", flush=True)
        senha = ""
        while True:
            ch = msvcrt.getch()
            if ch in {b"\r", b"\n"}:  # Enter
                print()
                break
            elif ch == b"\x08":  # Backspace
                if len(senha) > 0:
                    senha = senha[:-1]
                    print("\b \b", end="", flush=True)
            else:
                senha += ch.decode("utf-8")
                print("*", end="", flush=True)
        return senha

    # Uso no seu código
    input_nome = input("Usuário: ")
    input_senha = input_senha("Digite sua senha: ")


    print()
    print("[ ! ] Digite o comando 'help' para listar os comandos do sistema.")
    print()

    # >>> FUNÇÕES DOS COMANDOS <<<

    def help():
        print("-" * 40)
        print("COMANDO            EXPLICAÇÃO         ")
        print("-" * 40)
        print("help -> Mostrar e explicar comandos do sistema.")
        print("lst -> Lista arquivos e pastas do diretório atual.")
        print("infosys -> Ver informações do sistema.")
        print("echo -> Mostrar uma mensagem no terminal.")
        print("setcolors -> Mudar cor do terminal.")
        print("clear -> Limpar terminal.")
        print("useradmin -> Trocar para usuário Administrador.")
        print("shutdown -> Desliga o computador (somente para admins).")
        print("exit -> Sair do PROMPT DE COMANDO.")
        print("-" * 40)

    def lst():
        print()
        print("-" * 40)
        os.system("dir")
        print("-" * 40)
        print()

    def infosys():
        print()
        print("-" * 40)
        os.system("systeminfo")
        print("-" * 40)
        print()

    def echo(args):
        if args:
            print("\n" + " ".join(args) + "\n")
        else:
            print("\nNenhum argumento fornecido.\n")

    def setcolors():
        print()
        print("-" * 30)
        print("Lista de cores:")
        print("-" * 30)
        print("[ 1 ] Azul")
        print("[ 2 ] Verde")
        print("[ 3 ] Vermelho")
        print("[ 4 ] Roxo")
        print("[ 5 ] Amarelo")
        print("[ 6 ] Rosa")
        print("-" * 30)

        cor = input("Digite o código da cor: ").strip()

        cores = {
            "1": "1",
            "2": "2",
            "3": "4",
            "4": "5",
            "5": "6",
            "6": "d"
        }

        if cor in cores:
            os.system(f"color {cores[cor]}")
        else:
            print("Código de cor inválido.\n")

    def clear():
        os.system("cls")

    def useradmin():
        nonlocal login_adm, nome_adm, input_senha

        print()
        nome_adm_input = input("Digite o nome do ADMIN: ").lower().strip()
        senha_adm_input = input("Digite a senha do ADMIN: ")
        print()

        login_adm = False

        for adm in lista_adms:
            if adm["nome"].lower() == nome_adm_input and adm["senha"] == senha_adm_input:
                login_adm = True
                nome_adm = nome_adm_input
                break

        if not login_adm:
            print("Nome ou senha incorretos do ADMIN.\n")

    # Verifica se usuário inicial já é admin
    for adm in lista_adms:
        if adm["nome"].lower() == input_nome and adm["senha"] == input_senha:
            login_adm = True
            nome_adm = input_nome

    def shutdown():
        if login_adm:
            os.system('shutdown /s /f /t 5 /c "O computador será desligado em 5 segundos pelo sistema Void OS."')
        else:
            print("\nAVISO: Apenas ADMINS podem usar este comando.\n")

    def exit():
        print("\nSaindo do PROMPT DE COMANDO . . .\n")
        sleep(2)

    # >>> LOOP PRINCIPAL DO TERMINAL <<<

    while True:
        if login_adm:
            prompt = f"~/#Admin/@{nome_adm}> "
        else:
            prompt = f"~/#User/@{input_nome}> "

        cmd = input(prompt).strip().lower()
        partes = cmd.split()

        if not partes:
            continue

        comando = partes[0]
        args = partes[1:]

        if comando == "help":
            help()
        elif comando == "lst":
            lst()
        elif comando == "infosys":
            infosys()
        elif comando == "echo":
            echo(args)
        elif comando == "setcolors":
            setcolors()
        elif comando == "clear":
            clear()
        elif comando == "useradmin":
            useradmin()
        elif comando == "shutdown":
            shutdown()
        elif comando == "exit":
            exit()
            break
        else:
            print(f"\nO comando '{cmd}' não é reconhecido pelo sistema.\n")

    print("\nPROMPT DE COMANDO encerrado com sucesso.")
