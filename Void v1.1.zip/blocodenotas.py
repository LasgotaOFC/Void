def iniciar_blocodenotas():
    import time
    import os
# importações Necessárias
    
    os.system('cls')
    notas = []
    contador = int(0)
    def mostrarnotas():
        os.system('cls')
        print()
        for contador, i in enumerate(notas, 1):
            print(f'{contador} - {i}')
            print()
            print('Digite "V" para voltar as opções')
            dig = input(': ')
            if dig == 'v':
                fecharmostrarnotas()
            else:
                print('Opção inválida')

    def adicionarnota():
        os.system('cls')
        adicnota = input('Digite a nota: ')
        notas.append(adicnota)
        print()

    def removernota():
        os.system('cls')
        remonota = int(input('Digite o número da nota que deseja remover: '))
        notas.pop(remonota - 1)
        print()

    def sair():
        print('Fechando programa')
        time.sleep(1.5)

    def fecharmostrarnotas():
        pass
# Funções

    while True:
        print('=' * 50)
        print('Bloco de Notas')
        print('=' * 50)
        print()
        print('------------- Opções -------------')
        print('1 - Mostrar notas')
        print('2 - Adicionar nota')
        print('3 - Remover nota')
        print('"sair" Fecha o programa')
        op = input('Opção desejada: ')
        if op == '1':
            mostrarnotas()
        elif op == '2':
            adicionarnota()
        elif op == '3':
            removernota()
        elif op.lower() == 'sair':
            sair()
            break
        else:
            print()
            print('Opção inválida! Tente novamente!')
            print()
            time.sleep(1)
# Loop Inicial