def iniciar_hack():
    import random
    import os
    import time
    os.system('color a')
    while True:
        letra = random.choice('abcdefghijklmnopqrstuvwxyz') ,
        random.randint(0, 1000) , 
        random.choice('abcdefghijklmnopqrstuvwxyz') , 
        random.randint(0, 1000) , 
        random.choice('abcdefghijklmnopqrstuvwxyz') ,
        random.randint(0, 1000) ,  
        random.choice('abcdefghijklmnopqrstuvwxyz') , 
        random.randint(0, 1000) , 
        print(letra * 200 , end='')
# Foda-se, fiquei com preguiça de comentar!