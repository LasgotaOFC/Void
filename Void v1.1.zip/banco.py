def iniciar_banco():
    import os
    import time

    saldo = 1000
    historico = []

    def fazerpix():
        nonlocal saldo
        os.system('cls')
        print(f'Seu saldo é de R${saldo}')
        qcont = input('Para qual conta você deseja fazer o pix: ')
        qpix = int(input('Quanto você deseja transferir R$'))
        saldo -= qpix
        historico.append(f'Pix enviado para {qcont} no valor de R${qpix}')
        print('Pix enviado com sucesso!')
        time.sleep(1.5)

    def depositar():
        nonlocal saldo
        os.system('cls')
        print(f'Seu saldo é de R${saldo}')
        qdep = int(input('Quanto vc deseja depositar R$'))
        saldo += qdep
        historico.append(f'Depósito recebido no valor de R${qdep}')
        print('Depósito realizado com sucesso!')
        time.sleep(1.5)

    def mostrar_historico():
        os.system('cls')
        os.system('color a')
        for i in historico:
            print(i)
        os.system('color')
        print()
        input(': ')

    def mostraropcoes():
        os.system('cls')
        print(f'Seu saldo é de R${saldo}')
        print('=' * 50)
        print('Operações')
        print('=' * 50)
        print()
        print('1 - Fazer um pix')
        print('2 - Depositar')
        print('3 - Histórico de transações')
        print('"sair" Fecha o programa')
        op = input('Selecione a operação desejada: ')
        if op == '1':
            fazerpix()
            return True
        elif op == '2':
            depositar()
            return True
        elif op == '3':
            mostrar_historico()
            return True
        elif op.lower() == 'sair':
            return False
        return True

    while mostraropcoes():
        pass
