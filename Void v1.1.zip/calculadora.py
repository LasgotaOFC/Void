def iniciar_calculadora():
    import time
    import os
    os.system('cls')
    def somar(*numeros):
        try:
            return sum(numeros)
        except TypeError:
            raise ValueError("Senhor, é preciso de um número para somar.")


    def subtrair(*numeros):
        t_num = numeros[0]
        for n in numeros[1:]:
            t_num -= n
        return t_num


    def multiplicar(*numeros):
        t_num = 1
        for n in numeros:
            t_num *= n
        return t_num


    def dividir(*numeros):
        try:
            t_num = numeros[0]
            for n in numeros[1:]:
                t_num /= n
            return t_num
        except ZeroDivisionError:
            raise ValueError("Senhor, não é possível dividir por zero.")


    def calculadora():
        operacoes = {
            '1': ('Somar', somar),
            '2': ('Subtrair', subtrair),
            '3': ('Multiplicar', multiplicar),
            '4': ('Dividir', dividir)
        }

        time.sleep(1)

        print("=" * 50)
        print(' Calculadora '.center(50, '-'))
        print("=" * 50)
        print("Feito por: Lasgota e Frágil")

        time.sleep(1)

        print('Operações:')
        time.sleep(0.2)
        print('[1] - Somar')
        time.sleep(0.2)
        print('[2] - Subtrair')
        time.sleep(0.2)
        print('[3] - Multiplicar')
        time.sleep(0.2)
        print('[4] - Dividir')
        time.sleep(0.2)
        print('"Sair" Fecha o programa!')

        time.sleep(0.1)

        op = input('Selecione a operação: ')

        time.sleep(0.1)

        if op.lower() == 'sair':
            return False

        if op not in operacoes:
            time.sleep(0.1)
            print("Operação inválida!")
            return True

        numbers = int(input("Quantos números deseja usar? "))

        if numbers < 2:
            time.sleep(0.1)
            print("É necessário pelo menos 2 números!")
            return True

        numeros = []
        for i in range(numbers):
            time.sleep(0.1)
            num = float(input(f"Digite o número {i + 1}: "))
            numeros.append(num)

        nome_op, funcao = operacoes[op]

        try:
            resultado = funcao(*numeros)
            time.sleep(0.5)
            print(f"O resultado de {nome_op.lower()} {', '.join(map(str, numeros))} é: {resultado}")
        except KeyboardInterrupt:
            print("")

        return True


    while calculadora():
        time.sleep(0.5)
        print()